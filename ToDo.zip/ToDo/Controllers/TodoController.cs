﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ToDo.Services;
using ToDo.Models;

namespace ToDo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TodoController : ControllerBase
    {
        private readonly TodoService _todoService;

        public TodoController(TodoService todoService)
        {
            _todoService = todoService;
        }

        [HttpPost("CreateToDo")]
        public IActionResult Create(TodoList newTodo)
        {
            _todoService.Add(newTodo);
            return CreatedAtAction(nameof(GetById), new { id = newTodo.ToDoId }, newTodo);
        }

        [HttpGet("GetAllToDo")]
        public IActionResult GetAll()
        {
            return Ok(_todoService.GetAll());
        }

        [HttpGet("GetById")]
        public IActionResult GetById(int id)
        {
            var todo = _todoService.GetById(id);
            if (todo == null) return NotFound();
            return Ok(todo);
        }

       

        [HttpPut("UpdateId")]
        public IActionResult Update(int id, TodoList updatedTodo)
        {
            var result = _todoService.Update(id, updatedTodo);
            if (!result) return NotFound();
            return NoContent();
        }

        [HttpDelete("DeleteTodo")]
        public IActionResult Delete(int id)
        {
            var result = _todoService.Delete(id);
            if (!result) return NotFound();
            return NoContent();
        }
    }

}

