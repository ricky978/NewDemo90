﻿namespace ToDo.Models
{
    public class TodoList
    {
        public int ToDoId { get; set; }
        public string? ToDoTitle { get; set; }
        public string? Description { get; set; }
        public bool IsCompleted { get; set; }
    }
}
