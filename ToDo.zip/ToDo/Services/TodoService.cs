﻿using System.Xml.Linq;
using ToDo.Models;

namespace ToDo.Services
{
    public class TodoService
    {
        private readonly List<TodoList> _todoItems = new();

        public IEnumerable<TodoList> GetAll() => _todoItems;

        public TodoList? GetById(int id) => _todoItems.FirstOrDefault(t => t.ToDoId == id);

        public void Add(TodoList newTodo)
        {
            newTodo.ToDoId = _todoItems.Any() ? _todoItems.Max(t => t.ToDoId) + 1 : 1;
            _todoItems.Add(newTodo);
        }

        public bool Update(int id, TodoList updatedTodo)
        {
            var existingTodo = GetById(id);
            if (existingTodo == null) return false;

            existingTodo.ToDoTitle = updatedTodo.ToDoTitle;
            existingTodo.Description = updatedTodo.Description;
            existingTodo.IsCompleted = updatedTodo.IsCompleted;
            return true;
        }

        public bool Delete(int id)
        {
            var todo = GetById(id);
            if (todo == null) return false;

            _todoItems.Remove(todo);
            return true;
        }
    }
}

